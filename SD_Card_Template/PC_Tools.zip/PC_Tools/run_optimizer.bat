@echo off
REM Nomad Image Optimizer - Windows Batch Script
REM WARNING: This script will PERMANENTLY compress and resize images

echo ======================================================================
echo   Nomad Image Optimizer - Windows
echo ======================================================================
echo.
echo   WARNING: This will PERMANENTLY modify your images!
echo   Images in Movies, Shows, and Books will be compressed.
echo.
echo ======================================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH
    echo Please install Python 3.6 or higher from python.org
    echo.
    pause
    exit /b 1
)

REM Check if Pillow is installed
python -c "import PIL" >nul 2>&1
if errorlevel 1 (
    echo Error: Pillow library is not installed
    echo Please install it with: pip install Pillow
    echo.
    pause
    exit /b 1
)

REM Get the directory where this script is located (includes trailing backslash)
set "SCRIPT_DIR=%~dp0"

REM Pass parent path directly to Python - Python resolves it correctly on all drives
python "%SCRIPT_DIR%img.py" "%SCRIPT_DIR%.."

echo.
echo ======================================================================
echo   Done!
echo ======================================================================
echo.
pause
