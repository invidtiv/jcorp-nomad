#!/usr/bin/env python3
"""
Nomad Media Indexer v2.1
Generates NDJSON index files for ESP32 Nomad device
Matches firmware indexing logic exactly
"""

import os
import sys
import time
from pathlib import Path
from typing import List, Tuple, Optional

VERSION = "2.1.0"
INDEX_DIR = ".system-index"

# File extension detection (matching firmware isMediaFile)
VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".ts", ".m2ts", ".avi", ".flv", ".rmvb"}
AUDIO_EXTS = {".mp3", ".flac", ".wav", ".aac", ".m4a", ".ogg", ".opus"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".avif", ".gif", ".bmp", ".tiff", ".tif", ".heic"}
BOOK_EXTS = {".pdf", ".epub", ".txt", ".html", ".htm", ".cbz", ".cbr", ".azw3", ".mobi"}

# Buckets to index (matching indexWorkerTask order)
BUCKETS = ["/Shows", "/Music", "/Movies", "/Books", "/Gallery", "/Files", "/"]

# Folders to skip (matching firmware)
SKIP_FOLDERS = {".system-index", "System Volume Information", "Archive", "$RECYCLE.BIN", 
                ".Trash", ".Spotlight-V100", ".fseventsd", ".TemporaryItems"}

class ProgressBar:
    def __init__(self, total: int, prefix: str = "Progress", length: int = 50):
        self.total = total
        self.prefix = prefix
        self.length = length
        self.current = 0

    def update(self, current: int = None, suffix: str = ""):
        if current is not None:
            self.current = current
        else:
            self.current += 1

        percent = min(100, int(100 * self.current / self.total)) if self.total > 0 else 100
        filled = int(self.length * self.current / self.total) if self.total > 0 else self.length
        bar = '=' * filled + '-' * (self.length - filled)

        print(f'\r{self.prefix} [{bar}] {percent}% {suffix}', end='', flush=True)

        if self.current >= self.total:
            print()

def sanitize_token(s: str) -> str:
    """Sanitize a directory name into a filename token (matching firmware)"""
    out = []
    for c in s:
        if c.isalnum() or c in ('-', '_'):
            out.append(c)
        else:
            out.append('_')
    return ''.join(out) if out else '_'

def json_escape(s: str) -> str:
    """JSON escape matching firmware jsonEscape"""
    s = s.replace('\\', '\\\\')
    s = s.replace('"', '\\"')
    s = s.replace('\n', '\\n')
    s = s.replace('\r', '\\r')
    return s

def fnv1a64(data: str) -> int:
    """FNV-1a 64-bit hash matching firmware"""
    fnv_prime = 0x100000001b3
    hash_value = 0xcbf29ce484222325
    
    for byte in data.encode('utf-8'):
        hash_value ^= byte
        hash_value = (hash_value * fnv_prime) & 0xFFFFFFFFFFFFFFFF
    
    return hash_value

def normalize_path(path: str) -> str:
    """Normalize path matching firmware normalizePath"""
    if not path:
        return "/"
    if not path.startswith("/"):
        path = "/" + path
    while len(path) > 1 and path.endswith("/"):
        path = path[:-1]
    return path

def is_comic_folder(dir_path: Path) -> bool:
    """Detect comic folders matching firmware isComicFolder"""
    if not dir_path.is_dir():
        return False
    
    has_images = False
    has_book_files = False
    image_count = 0
    
    try:
        for item in dir_path.iterdir():
            if item.is_file():
                ext = item.suffix.lower()
                
                # Check for book/audio files that would make this NOT a comic folder
                if ext in {'.pdf', '.epub', '.azw3', '.mobi', '.mp3', '.m4a', '.m4b', '.flac'}:
                    has_book_files = True
                    break
                
                # Count images
                if ext in {'.png', '.jpg', '.jpeg', '.webp'}:
                    has_images = True
                    image_count += 1
        
        # Comic folder if it has images but no book files, and at least 3 images
        return has_images and not has_book_files and image_count >= 3
    except Exception:
        return False

def should_skip_folder(path: str, name: str) -> bool:
    """Check if folder should be skipped matching firmware shouldSkipFolder"""
    # Skip hidden files/folders
    if name.startswith('.') or name.startswith('$'):
        return True
    
    # Skip system folders
    for skip in SKIP_FOLDERS:
        if name == skip or path.startswith(f"/{skip}"):
            return True
    
    return False

def determine_max_depth(norm_path: str) -> int:
    """Determine recursion depth matching firmware logic exactly"""
    # Root directory - no recursion
    if norm_path == "/":
        return 0
    
    # Books at any level - no recursion
    if norm_path == "/Books":
        return 0
    if norm_path.startswith("/Books/"):
        # Books subfolder or comic folder - all get depth 0
        return 0
    
    # Everything else gets full recursion
    return 10

def count_and_hash_entries(dir_path: Path, root_path: Path, max_depth: int) -> Tuple[int, int]:
    """Count entries and compute hash matching firmware prepass"""
    count = 0
    sig = 0xcbf29ce484222325  # FNV offset basis
    
    def scan(path: Path, depth: int = 0):
        nonlocal count, sig
        
        if depth > max_depth:
            return
        
        try:
            for item in sorted(path.iterdir()):
                name = item.name
                
                # Skip hidden/system folders
                if should_skip_folder(str(item), name):
                    continue
                
                # Get full path relative to root
                try:
                    full_path = "/" + str(item.relative_to(root_path)).replace('\\', '/')
                except ValueError:
                    continue
                
                if item.is_dir():
                    # Skip comic folder contents
                    if full_path.startswith("/Books/") and is_comic_folder(item):
                        continue
                    
                    # Update signature for directory
                    sig_data = f"{full_path}|{name}"
                    sig = fnv1a64(sig_data) ^ sig
                    count += 1
                    
                    # Recurse
                    scan(item, depth + 1)
                else:
                    # Update signature for file
                    size = item.stat().st_size
                    mtime = 0  # Firmware uses 0 for mtime
                    sig_data = f"{full_path}|{size}|{mtime}"
                    sig = fnv1a64(sig_data) ^ sig
                    count += 1
                    
        except Exception as e:
            print(f"\n  Warning: Error scanning {path}: {e}")
    
    scan(dir_path)
    return count, sig

def write_index_for_dir(dir_path: Path, output_filename: str, root_path: Path) -> Tuple[bool, int]:
    """Write NDJSON index file matching firmware writeNDIndexForDir"""
    if not dir_path.exists() or not dir_path.is_dir():
        return False, 0
    
    # Normalize path
    try:
        norm_path = normalize_path("/" + str(dir_path.relative_to(root_path)).replace('\\', '/'))
    except ValueError:
        norm_path = "/"
    
    # Determine max depth
    max_depth = determine_max_depth(norm_path)
    
    # Count entries and compute signature
    count, sig = count_and_hash_entries(dir_path, root_path, max_depth)
    
    # Ensure index directory exists
    index_dir = root_path / INDEX_DIR
    index_dir.mkdir(exist_ok=True)
    
    # Write to temp file first
    tmp_path = index_dir / f"{output_filename}.tmp"
    final_path = index_dir / output_filename
    
    try:
        with open(tmp_path, 'w', encoding='utf-8') as f:
            # Write header matching firmware buildIndexHeader
            sig_hex = f"{sig:016x}"
            header = f'{{"_type":"dir","path":"{json_escape(norm_path)}","sig":"{sig_hex}","count":{count}}}\n'
            f.write(header)
            
            # Write entries matching firmware writepass
            def write_entries(path: Path, depth: int = 0):
                if depth > max_depth:
                    return
                
                try:
                    for item in sorted(path.iterdir()):
                        name = item.name
                        
                        # Skip hidden/system folders
                        if should_skip_folder(str(item), name):
                            continue
                        
                        # Get full path
                        try:
                            full_path = "/" + str(item.relative_to(root_path)).replace('\\', '/')
                        except ValueError:
                            continue
                        
                        if item.is_dir():
                            # Skip comic folder contents but still list the folder
                            is_comic = full_path.startswith("/Books/") and is_comic_folder(item)
                            
                            # Write directory entry
                            comic_attr = ',\"comic\":true' if is_comic else ''
                            entry = f'{{"t":"d","n":"{json_escape(name)}","p":"{json_escape(full_path)}"{comic_attr}}}\n'
                            f.write(entry)
                            
                            # Recurse if not a comic folder
                            if not is_comic:
                                write_entries(item, depth + 1)
                        else:
                            # Write file entry
                            size = item.stat().st_size
                            mtime = 0  # Firmware uses 0
                            entry = f'{{"t":"f","n":"{json_escape(name)}","p":"{json_escape(full_path)}","sz":{size},"mt":{mtime}}}\n'
                            f.write(entry)
                            
                except Exception as e:
                    print(f"\n  Warning: Error writing entries for {path}: {e}")
            
            write_entries(dir_path)
        
        # Atomic rename
        if final_path.exists():
            final_path.unlink()
        tmp_path.rename(final_path)
        
        return True, count
    
    except Exception as e:
        print(f"\n  ✗ Error writing index for {dir_path}: {e}")
        if tmp_path.exists():
            tmp_path.unlink()
        return False, 0

def build_bucket_index(bucket_path: Path, root_path: Path, bucket_name: str) -> Tuple[bool, int]:
    """Build bucket index matching firmware buildBucketIndex"""
    # Determine output filename
    if bucket_name == "/":
        bucket = "root"
    else:
        bucket = bucket_name.lstrip('/').rstrip('/')
    
    output_filename = f"{bucket}.index.ndjson"
    
    return write_index_for_dir(bucket_path, output_filename, root_path)

def generate_media_indexes(root_path: Path):
    """Generate all media indexes matching firmware generateMediaJson + indexWorkerTask"""
    print(f"\n{'='*70}")
    print(f"  Nomad Media Indexer v{VERSION}")
    print(f"{'='*70}")
    print(f"  Root: {root_path}")
    print(f"  Index Directory: {INDEX_DIR}")
    print(f"{'='*70}\n")

    start_time = time.time()
    total_files = 0

    # Process each bucket (matching indexWorkerTask order)
    progress = ProgressBar(len(BUCKETS), prefix="Indexing Buckets", length=40)

    for i, bucket in enumerate(BUCKETS):
        bucket_path = root_path if bucket == "/" else root_path / bucket.lstrip('/')

        if not bucket_path.exists():
            progress.update(i + 1, f"[SKIP] {bucket}")
            continue

        print(f"\n[Indexing] {bucket}")
        success, count = build_bucket_index(bucket_path, root_path, bucket)

        if success:
            total_files += count
            print(f"  [OK] Indexed {count} items")
        else:
            print(f"  [FAILED] Could not index")

        # Generate nested indexes (matching generateMediaJson)
        if bucket == "/Shows" and bucket_path.exists():
            print(f"  Indexing show subdirectories...")
            show_count = 0
            try:
                for show_dir in sorted(bucket_path.iterdir()):
                    if show_dir.is_dir() and not should_skip_folder(str(show_dir), show_dir.name):
                        show_name = show_dir.name
                        file_token = f"Shows__{sanitize_token(show_name)}.nested.ndjson"
                        success, count = write_index_for_dir(show_dir, file_token, root_path)
                        if success:
                            show_count += 1
                            total_files += count
            except Exception as e:
                print(f"  Warning: Error indexing shows: {e}")
            print(f"  [OK] Indexed {show_count} shows")

        elif bucket == "/Music" and bucket_path.exists():
            print(f"  Indexing music subdirectories...")
            music_count = 0
            try:
                for music_dir in sorted(bucket_path.iterdir()):
                    if music_dir.is_dir() and not should_skip_folder(str(music_dir), music_dir.name):
                        music_name = music_dir.name
                        file_token = f"Music__{sanitize_token(music_name)}.nested.ndjson"
                        success, count = write_index_for_dir(music_dir, file_token, root_path)
                        if success:
                            music_count += 1
                            total_files += count
            except Exception as e:
                print(f"  Warning: Error indexing music: {e}")
            print(f"  [OK] Indexed {music_count} albums/playlists")

        elif bucket == "/Books" and bucket_path.exists():
            print(f"  Indexing book subdirectories...")
            book_count = 0
            try:
                for book_dir in sorted(bucket_path.iterdir()):
                    if book_dir.is_dir() and not should_skip_folder(str(book_dir), book_dir.name):
                        # Skip comic folders from getting nested indexes
                        if not is_comic_folder(book_dir):
                            book_name = book_dir.name
                            file_token = f"Books__{sanitize_token(book_name)}.nested.ndjson"
                            success, count = write_index_for_dir(book_dir, file_token, root_path)
                            if success:
                                book_count += 1
                                total_files += count
                        else:
                            print(f"    - Skipping comic folder: {book_dir.name}")
            except Exception as e:
                print(f"  Warning: Error indexing books: {e}")
            print(f"  [OK] Indexed {book_count} book subdirectories")

        progress.update(i + 1, f"[OK] {bucket}")

    print(f"\n{'='*70}")

    # Generate media.json summary (matching firmware)
    summary_lines = []
    summary_lines.append('{')
    summary_lines.append('  "generated": true,')
    summary_lines.append('  "buckets": {')

    index_dir = root_path / INDEX_DIR
    bucket_entries = []

    if index_dir.exists():
        for index_file in sorted(index_dir.glob("*.ndjson")):
            if index_file.suffix == ".ndjson":
                try:
                    with open(index_file, 'r', encoding='utf-8') as f:
                        header = f.readline().strip()
                        if header and '"count":' in header:
                            # Extract count from header
                            count_pos = header.find('"count":')
                            if count_pos >= 0:
                                count_start = count_pos + 8
                                count_end = count_start
                                while count_end < len(header) and header[count_end].isdigit():
                                    count_end += 1
                                count_str = header[count_start:count_end] if count_end > count_start else "0"
                                bucket_entries.append(f'    "{index_file.name}": {count_str}')
                except Exception:
                    pass

    summary_lines.append(',\n'.join(bucket_entries))
    summary_lines.append('  }')
    summary_lines.append('}')

    media_json = '\n'.join(summary_lines) + '\n'

    # Write media.json
    media_json_path = root_path / "media.json"
    try:
        with open(media_json_path, 'w', encoding='utf-8') as f:
            f.write(media_json)
        print(f"  [OK] Created media.json summary")
    except Exception as e:
        print(f"  [FAILED] Could not write media.json: {e}")

    # Show statistics
    elapsed = time.time() - start_time
    print(f"\n  Statistics:")
    print(f"     Total Items Indexed: {total_files:,}")
    print(f"     Buckets Processed: {len([b for b in BUCKETS if (root_path if b == '/' else root_path / b.lstrip('/')).exists()])}")
    print(f"     Time Elapsed: {elapsed:.2f}s")
    print(f"\n{'='*70}")
    print(f"  Indexing Complete")
    print(f"{'='*70}\n")

def main():
    if len(sys.argv) > 1:
        root_path = Path(sys.argv[1]).resolve()
    else:
        root_path = Path.cwd()

    if not root_path.exists():
        print(f"Error: Path does not exist: {root_path}")
        sys.exit(1)

    try:
        generate_media_indexes(root_path)
    except KeyboardInterrupt:
        print("\n\n[WARNING] Indexing interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n[FATAL] Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
