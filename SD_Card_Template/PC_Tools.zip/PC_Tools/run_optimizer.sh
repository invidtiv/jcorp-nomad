#!/bin/bash
# Nomad Image Optimizer - macOS/Linux Shell Script
# WARNING: This script will PERMANENTLY compress and resize images

echo "======================================================================"
echo "  Nomad Image Optimizer - macOS/Linux"
echo "======================================================================"
echo ""
echo "  WARNING: This will PERMANENTLY modify your images!"
echo "  Images in Movies, Shows, and Books will be compressed."
echo ""
echo "======================================================================"
echo ""

if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed or not in PATH"
    echo "Please install Python 3.6 or higher"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

if ! python3 -c "import PIL" &> /dev/null; then
    echo "Error: Pillow library is not installed"
    echo "Please install it with: pip3 install Pillow"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SD_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

python3 "$SCRIPT_DIR/img.py" "$SD_ROOT"

echo ""
echo "======================================================================"
echo "  Done!"
echo "======================================================================"
echo ""
read -p "Press Enter to exit..."
