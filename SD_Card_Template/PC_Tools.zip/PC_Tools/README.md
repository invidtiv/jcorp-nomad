  Nomad Media Indexer v2.1.0
======================================================================
  Root: /path/to/sd/card
  Index Directory: .system-index
======================================================================

[Indexing] /Shows
  [OK] Indexed 15 items
  Indexing show subdirectories...
  [OK] Indexed 3 shows
Indexing Buckets [========================================] 100% [OK] /

======================================================================
  [OK] Created media.json summary

  Statistics:
     Total Items Indexed: 423
     Buckets Processed: 7
     Time Elapsed: 1.25s

======================================================================
  Indexing Complete
======================================================================
```

## Troubleshooting

**"Python is not installed or not in PATH" (Windows):**
- Reinstall Python and check "Add Python to PATH"
- Or add Python to PATH manually in System Environment Variables

**"command not found: python3" (macOS/Linux):**
- Install Python 3 using your system's package manager

**Permission denied (macOS/Linux):**
- Make the script executable: `chmod +x run_indexer.sh`
- Or run with: `bash run_indexer.sh`

**Indexing takes a long time:**
- Normal for large media libraries (1000+ files)
- The Nomad device will use these indexes for instant browsing

## Notes

- Run the indexer whenever you add or remove media files
- The indexer skips hidden folders and system directories
- Comic book folders (image-only folders) are detected automatically
- Nested directories are supported for Shows, Music, and Books
=======
# PC Tools for Nomad Device

This folder contains utilities for managing your Nomad device's SD card.

---

# Nomad Media Indexer

## Overview

The Media Indexer generates index files for your Nomad device's SD card, enabling fast media browsing. It scans your media directories and creates NDJSON index files in the `.system-index` folder.

## Requirements

- **Python 3.6 or higher**
- No additional Python packages required (uses standard library only)

## Installation

### Windows

1. Install Python from [python.org](https://www.python.org/downloads/)
2. During installation, check "Add Python to PATH"
3. Verify installation:
   ```
   python --version
   ```

### macOS

Python 3 is usually pre-installed. If not:
```bash
brew install python3
```

Verify installation:
```bash
python3 --version
```

### Linux

Most distributions include Python 3. If not:

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install python3
```

**Fedora/RHEL:**
```bash
sudo dnf install python3
```

Verify installation:
```bash
python3 --version
```

## Usage

### Method 1: Run Script (Recommended)

**Windows:**
1. Open the `PC_Tools` folder on your SD card
2. Double-click `run_indexer.bat`
3. Wait for indexing to complete
4. Press any key to close the window

**macOS/Linux:**
1. Open Terminal
2. Navigate to the PC_Tools folder:
   ```bash
   cd /path/to/sd/card/PC_Tools
   ```
3. Make the script executable (first time only):
   ```bash
   chmod +x run_indexer.sh
   ```
4. Run the script:
   ```bash
   ./run_indexer.sh
   ```

### Method 2: Run Directly

From the `PC_Tools` folder:

**Windows:**
```
python media_indexer.py ..
```

**macOS/Linux:**
```bash
python3 media_indexer.py ..
```

## What It Does

The indexer scans these directories on your SD card:
- `/Shows` - TV shows and series
- `/Music` - Music albums and playlists
- `/Movies` - Movie files
- `/Books` - PDFs, ebooks, audiobooks
- `/Gallery` - Photos and images
- `/Files` - General files

It creates:
- Bucket index files (e.g., `Movies.index.ndjson`)
- Nested indexes for subdirectories (e.g., `Shows__ShowName.nested.ndjson`)
- A `media.json` summary file

All index files are stored in `/.system-index/`

## Output

You will see:
```
======================================================================
  Nomad Media Indexer v2.1.0
======================================================================
  Root: /path/to/sd/card
  Index Directory: .system-index
======================================================================

[Indexing] /Shows
  [OK] Indexed 15 items
  Indexing show subdirectories...
  [OK] Indexed 3 shows
Indexing Buckets [========================================] 100% [OK] /

======================================================================
  [OK] Created media.json summary

  Statistics:
     Total Items Indexed: 423
     Buckets Processed: 7
     Time Elapsed: 1.25s

======================================================================
  Indexing Complete
======================================================================
```

## Troubleshooting

**"Python is not installed or not in PATH" (Windows):**
- Reinstall Python and check "Add Python to PATH"
- Or add Python to PATH manually in System Environment Variables

**"command not found: python3" (macOS/Linux):**
- Install Python 3 using your system's package manager

**Permission denied (macOS/Linux):**
- Make the script executable: `chmod +x run_indexer.sh`
- Or run with: `bash run_indexer.sh`

**Indexing takes a long time:**
- Normal for large media libraries (1000+ files)
- The Nomad device will use these indexes for instant browsing

## Notes

- Run the indexer whenever you add or remove media files
- The indexer skips hidden folders and system directories
- Comic book folders (image-only folders) are detected automatically
- Nested directories are supported for Shows, Music, and Books

---

# Nomad Image Optimizer

## ⚠️ WARNING - DESTRUCTIVE OPERATION ⚠️

**This tool PERMANENTLY modifies your images. Original files will be OVERWRITTEN with no backup.**

The Image Optimizer compresses and resizes cover images in Movies, Shows, and Books directories to reduce SD card space and improve loading times on the Nomad device.

## What It Does

- Scans `/Movies` (all subdirectories), `/Shows` (root folder only), and `/Books` (one level deep)
- Finds all JPG/JPEG images
- Resizes images to 200px width (maintaining aspect ratio)
- Compresses to 75% JPEG quality
- **OVERWRITES original files** (no backup is created)

## Requirements

- **Python 3.6 or higher**
- **Pillow library** (Python image processing library)

### Installing Pillow

**Windows:**
```
pip install Pillow
```

**macOS/Linux:**
```bash
pip3 install Pillow
```

## Usage

### Method 1: Run Script (Recommended)

**Windows:**
1. Open the `PC_Tools` folder on your SD card
2. Double-click `run_optimizer.bat`
3. **READ THE WARNING CAREFULLY**
4. Type `YES` to confirm or `NO` to cancel
5. Wait for processing to complete

**macOS/Linux:**
1. Open Terminal
2. Navigate to the PC_Tools folder:
   ```bash
   cd /path/to/sd/card/PC_Tools
   ```
3. Make the script executable (first time only):
   ```bash
   chmod +x run_optimizer.sh
   ```
4. Run the script:
   ```bash
   ./run_optimizer.sh
   ```
5. **READ THE WARNING CAREFULLY**
6. Type `YES` to confirm or `NO` to cancel

### Method 2: Run Directly

From the `PC_Tools` folder:

**Windows:**
```
python img.py ..
```

**macOS/Linux:**
```bash
python3 img.py ..
```

## Output

You will see:
```
======================================================================
  ⚠️  WARNING - DESTRUCTIVE OPERATION ⚠️
======================================================================

  This script will PERMANENTLY MODIFY all JPG/JPEG images in:
    - /Movies (all subdirectories)
    - /Shows (root folder only)
    - /Books (one level deep)

  Changes that will be made:
    ✗ Images will be resized to 200px width
    ✗ Images will be compressed to 75% JPEG quality
    ✗ Original files will be OVERWRITTEN (no backup)

  ⚠️  THIS CANNOT BE UNDONE! ⚠️

======================================================================

  Type 'YES' to continue or 'NO' to cancel: YES

======================================================================
  Nomad Image Optimizer v1.0.0
======================================================================
  Root: /path/to/sd/card
  Target Width: 200px
  JPEG Quality: 75%
======================================================================

[Processing] /Movies (all subdirectories)
  [COMPRESSED] poster.jpg -> 200px width
  [OK] Compressed: 15, Skipped: 3, Errors: 0

======================================================================
  Optimization Complete

  Statistics:
     Images Compressed: 45
     Images Skipped: 12
     Errors: 0
======================================================================
```

## When to Use

- **Before first use:** Optimize images once to reduce SD card space
- **After adding new content:** Run again to optimize new cover images
- **Large libraries:** Can save significant SD card space (typically 50-80% reduction)

## What Gets Skipped

- Images already 200px wide or smaller
- Non-JPG/JPEG files (PNG, WebP, etc.)
- Hidden files and system directories
- Shows subdirectories (only root-level images in /Shows are processed)
- Deep Books subdirectories (only /Books root and immediate subdirectories are processed)

## Troubleshooting

**"Pillow library is not installed":**
- Install with `pip install Pillow` (Windows) or `pip3 install Pillow` (macOS/Linux)

**"Permission denied" errors:**
- Check that you have write permissions to the SD card
- Try running with administrator/sudo privileges

**Some images show errors:**
- Corrupted or invalid JPEG files will be skipped
- Check the error message for the specific file

## Important Notes

- ⚠️ **BACKUP YOUR IMAGES FIRST** if you want to preserve originals
- This operation cannot be undone
- Only affects JPG/JPEG files (PNG, WebP, etc. are not modified)
- Images are optimized in-place (no temporary copies)
- Processing large libraries may take several minutes

---

## License

These tools are provided as-is for use with the Nomad device.
