#!/bin/bash
# Nomad Media Indexer - macOS/Linux Shell Script
# Run this script from the PC_Tools folder to index your SD card

echo "======================================================================"
echo "  Nomad Media Indexer - macOS/Linux"
echo "======================================================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed"
    echo "Please install Python 3.6 or higher"
    echo ""
    exit 1
fi

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Get parent directory (SD card root)
SD_ROOT="$(dirname "$SCRIPT_DIR")"

# Run the indexer on the SD card root
echo "Indexing SD card at: $SD_ROOT"
echo ""
python3 "$SCRIPT_DIR/media_indexer.py" "$SD_ROOT"

echo ""
echo "======================================================================"
echo "  Done! You can now safely eject your SD card."
echo "======================================================================"
echo ""
