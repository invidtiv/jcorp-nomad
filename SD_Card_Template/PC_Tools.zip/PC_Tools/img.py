#!/usr/bin/env python3
"""
Nomad Image Optimizer v1.0
Compresses and resizes cover images for Movies, Shows, and Books
WARNING: This script will PERMANENTLY modify original images
"""

import os
import sys
from pathlib import Path
from typing import List

VERSION = "1.0.0"

try:
    from PIL import Image
except ImportError:
    print("ERROR: Pillow library is not installed")
    print("Please install it with: pip install Pillow")
    sys.exit(1)

IMAGE_EXTENSIONS = {".jpg", ".jpeg"}
MAX_WIDTH = 200
JPEG_QUALITY = 75

class ImageOptimizer:
    def __init__(self, root_path: Path):
        self.root_path = root_path
        self.processed_count = 0
        self.skipped_count = 0
        self.error_count = 0

    def resize_image(self, image_path: Path) -> bool:
        try:
            with Image.open(image_path) as img:
                width, height = img.size

                if width <= MAX_WIDTH:
                    return False

                new_height = int((MAX_WIDTH / width) * height)
                img_resized = img.resize((MAX_WIDTH, new_height), Image.Resampling.LANCZOS)

                img_resized.save(image_path, 'JPEG', quality=JPEG_QUALITY, optimize=True)
                return True

        except Exception as e:
            print(f"  [ERROR] Failed to process {image_path.name}: {e}")
            return None

    def process_directory(self, directory: Path, max_depth: int = -1, current_depth: int = 0) -> tuple:
        processed = 0
        skipped = 0
        errors = 0

        try:
            items = list(directory.iterdir())
        except PermissionError:
            return (0, 0, 1)

        for item in items:
            if item.is_file() and item.suffix.lower() in IMAGE_EXTENSIONS:
                result = self.resize_image(item)
                if result is True:
                    processed += 1
                    print(f"  [COMPRESSED] {item.name} -> {MAX_WIDTH}px width")
                elif result is False:
                    skipped += 1
                elif result is None:
                    errors += 1

            elif item.is_dir() and not item.name.startswith('.'):
                if max_depth == -1 or current_depth < max_depth:
                    sub_processed, sub_skipped, sub_errors = self.process_directory(
                        item, max_depth, current_depth + 1
                    )
                    processed += sub_processed
                    skipped += sub_skipped
                    errors += sub_errors

        return (processed, skipped, errors)

    def optimize_images(self):
        print("\n" + "="*70)
        print(f"  Nomad Image Optimizer v{VERSION}")
        print("="*70)
        print(f"  Root: {self.root_path}")
        print(f"  Target Width: {MAX_WIDTH}px")
        print(f"  JPEG Quality: {JPEG_QUALITY}%")
        print("="*70)
        print()

        folders_config = [
            ("Movies", -1),
            ("Shows", 0),
            ("Books", 1),
        ]

        for folder_name, max_depth in folders_config:
            folder_path = self.root_path / folder_name

            if not folder_path.exists():
                print(f"[SKIP] /{folder_name} (not found)")
                continue

            depth_desc = "root only" if max_depth == 0 else f"{max_depth} level deep" if max_depth > 0 else "all subdirectories"
            print(f"[Processing] /{folder_name} ({depth_desc})")
            processed, skipped, errors = self.process_directory(folder_path, max_depth)

            self.processed_count += processed
            self.skipped_count += skipped
            self.error_count += errors

            print(f"  [OK] Compressed: {processed}, Skipped: {skipped}, Errors: {errors}")
            print()

        print("="*70)
        print(f"  Optimization Complete")
        print()
        print(f"  Statistics:")
        print(f"     Images Compressed: {self.processed_count}")
        print(f"     Images Skipped: {self.skipped_count}")
        print(f"     Errors: {self.error_count}")
        print("="*70)
        print()


def show_warning() -> bool:
    print()
    print("="*70)
    print("  ⚠️  WARNING - DESTRUCTIVE OPERATION ⚠️")
    print("="*70)
    print()
    print("  This script will PERMANENTLY MODIFY all JPG/JPEG images in:")
    print("    - /Movies (all subdirectories)")
    print("    - /Shows (root folder only)")
    print("    - /Books (one level deep)")
    print()
    print("  Changes that will be made:")
    print(f"    ✗ Images will be resized to {MAX_WIDTH}px width")
    print(f"    ✗ Images will be compressed to {JPEG_QUALITY}% JPEG quality")
    print("    ✗ Original files will be OVERWRITTEN (no backup)")
    print()
    print("  ⚠️  THIS CANNOT BE UNDONE! ⚠️")
    print()
    print("="*70)
    print()

    while True:
        response = input("  Type 'YES' to continue or 'NO' to cancel: ").strip()
        if response.upper() == 'YES':
            return True
        elif response.upper() == 'NO':
            return False
        else:
            print("  Please type 'YES' or 'NO'")


def main():
    if len(sys.argv) > 1:
        root_path = Path(sys.argv[1]).resolve()
    else:
        root_path = Path.cwd()

    if not root_path.exists():
        print(f"Error: Path does not exist: {root_path}")
        sys.exit(1)

    if not show_warning():
        print("\n  Operation cancelled by user.")
        print()
        sys.exit(0)

    print()

    try:
        optimizer = ImageOptimizer(root_path)
        optimizer.optimize_images()
    except KeyboardInterrupt:
        print("\n\n[WARNING] Operation interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n[FATAL] Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
