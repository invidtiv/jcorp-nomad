@echo off
REM Nomad Media Indexer - Windows Batch Script
REM Run this script from the PC_Tools folder to index your SD card

echo ======================================================================
echo   Nomad Media Indexer - Windows
echo ======================================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH
    echo Please install Python 3.6 or higher from python.org
    echo.
    pause
    exit /b 1
)

REM Get the directory where this script is located (includes trailing backslash)
set "SCRIPT_DIR=%~dp0"

REM Pass parent path directly to Python - Python resolves it correctly on all drives
REM %SCRIPT_DIR%.. means "parent of PC_Tools folder" = SD card root
python "%SCRIPT_DIR%media_indexer.py" "%SCRIPT_DIR%.."

echo.
echo ======================================================================
echo   Done! You can now safely eject your SD card.
echo ======================================================================
echo.
pause
